# CrossSync Agent — Build Plan

A polished, Linear/Vercel-style B2B SaaS dashboard for an agent that syncs a Lovable web app with a Replit mobile app. Light theme, white cards, soft neutral background, subtle shadows, clear status colors.

## Design system

Update `src/styles.css` tokens (light theme only, no dark work needed for now):
- Background: soft neutral (`oklch(0.985 0.003 250)`)
- Card: pure white with subtle border + soft shadow
- Primary: refined blue (`oklch(0.55 0.19 255)`)
- Status colors as semantic tokens: `--success` (green), `--warning` (amber), `--danger` (red), `--info` (blue), `--muted-status` (gray)
- Radius: `0.75rem` for cards, `0.5rem` for controls
- Typography: system-first UI stack, tight tracking on headings, `font-feature-settings` for tabular numerals in metrics
- Add a `StatusBadge` and `StatusDot` component driven by a `status` variant (in-sync, running, changed, review, failed, pending, complete, blocked)

## App shell

`src/routes/__root.tsx` — update head metadata to "CrossSync Agent" / real description. Keep it as router root only.

New layout route `src/routes/_app.tsx` that renders:
- `SidebarProvider` + `AppSidebar` (shadcn sidebar) with items: Dashboard, Sync Activity, Platform Context, Design Consistency, Feature Mapping, Human Review, Agent Settings
- Top bar with product name "CrossSync Agent", global sync status pill, agent run indicator, and a settings/avatar cluster
- `<Outlet />` for pages

Sidebar uses `Link` + `useRouterState` for active highlighting, `collapsible="icon"`.

## Routes

All pages under `_app` layout, each with its own `head()` metadata (title + description + og tags — no og:image).

1. `src/routes/_app.index.tsx` — **Dashboard** (`/`)
2. `src/routes/_app.activity.tsx` — **Sync Activity**
3. `src/routes/_app.context.tsx` — **Platform Context**
4. `src/routes/_app.design.tsx` — **Design Consistency**
5. `src/routes/_app.features.tsx` — **Feature Mapping**
6. `src/routes/_app.review.tsx` — **Human Review**
7. `src/routes/_app.settings.tsx` — **Agent Settings**

Delete/replace the placeholder `src/routes/index.tsx` content by moving home to `_app.index.tsx`.

## Page contents

### 1. Dashboard
- Hero **Sync Status Card**: large state pill with one of {In Sync, Lovable Changed, Replit Changed, Agent Running, Human Review Required, Sync Failed}, timestamp, last event summary, "View activity" link.
- **Platform pair**: two cards (Lovable Web / Replit Mobile) with an animated bidirectional connector between them (SVG with arrows + subtle pulse when agent is running). Each card shows: platform name, app type, last saved update, current detected change, sync status badge, context availability rows (design/feature for Lovable; code/build/test for Replit).
- **Agent Progress** section: horizontal stepper with the 7 stages and per-step status (Pending/Running/Complete/Blocked/Failed). Icon + label + subtle progress bar under the running step.
- **Recent Sync Activity** preview (last 5) with badges (UI Layout, Feature, Navigation, Content, Design System, Data/API, Bug Fix), platform origin chip, timestamp, action + result. Link to full activity page.
- **Quick stats** row: In-sync %, syncs today, pending reviews, failed syncs.

### 2. Sync Activity
- Filter bar (platform, change type, result, timeframe).
- Full timeline/table of activity items with the same fields as the dashboard preview, expandable rows showing agent action detail and diff summary.

### 3. Platform Context
- Two side-by-side panels (Lovable / Replit) each with grouped sections:
  - Lovable: Pages, Components, Design system tokens, Recent saved changes, UI hierarchy tree, Styling metadata.
  - Replit: Codebase tree, Components, Feature files, Git/file changes, Build status, Test status, Recent commits.
- MCP connection indicator at the top of each panel.

### 4. Design Consistency
- Checklist card with rows for: Typography, Color, Button hierarchy, Spacing/sizing, Navigation patterns, Form controls, Loading states, Error states, Empty states, Mobile responsiveness. Each row: status badge, severity (Low/Med/High), suggested fix, last checked.
- Sidebar/side card **"Common Web-to-Mobile Issues"** with the 5 listed patterns.

### 5. Feature Mapping
- Table (shadcn `Table`): Feature | Lovable Web | Replit Mobile | Last updated | Sync status | Required action.
- Status labels: Synced, Missing on Lovable, Missing on Replit, Outdated, Needs Review — color-coded badges.
- Search + status filter above the table.

### 6. Human Review Queue
- Card list. Each card: change summary, source → target platforms, reason for review, suggested agent action, and Approve / Reject / Edit instructions buttons. Reason chip uses one of the five defined triggers.

### 7. Agent Settings
- Grouped settings using `Card` + `Switch` + `RadioGroup` + `Select`:
  - Automation: enable auto-sync, require review before code changes, require review before design changes
  - Sync direction (radio): Lovable→Replit, Replit→Lovable, Bidirectional
  - Validation level (segmented): Light / Standard / Strict
  - Design consistency enforcement (segmented): Flexible / Balanced / Strict
  - MCP connections: Lovable + Replit status rows with Connected/Disconnected indicators and reconnect action

## Sample data

One module `src/data/sample.ts` exporting typed sample data for: platforms, agent steps, activity feed, design checks, feature map, review queue, settings defaults. Every page imports from here so the product feels alive and consistent across views.

## Shared components (`src/components/crosssync/`)
- `AppSidebar.tsx`, `Topbar.tsx`
- `StatusBadge.tsx`, `StatusDot.tsx`, `ChangeTypeBadge.tsx`
- `PlatformCard.tsx`, `SyncConnector.tsx` (animated SVG)
- `AgentProgress.tsx` (stepper)
- `ActivityItem.tsx`
- `SectionHeader.tsx`

Tailwind v4 utilities only, semantic tokens, no hardcoded hex in JSX. Framer Motion for the subtle connector pulse and status transitions.

## Out of scope
- Backend / real MCP integration (Lovable Cloud not enabled; all data is static sample data)
- Auth
- Dark theme polish beyond keeping tokens valid

import { defineMcp } from "@lovable.dev/mcp-js";
import listRecentChanges from "./tools/list-recent-changes";
import getDesignTokens from "./tools/get-design-tokens";
import getComponentHierarchy from "./tools/get-component-hierarchy";

export default defineMcp({
  name: "crosssync-lovable-mcp",
  title: "CrossSync — Lovable Context",
  version: "0.1.0",
  instructions:
    "Exposes the Lovable web app's context to a synchronization agent that keeps a Replit mobile app in parity. Use `list_recent_changes` to see what recently changed on Lovable, `get_design_tokens` to read the current design system (colors, radius, typography, spacing, motion), and `get_component_hierarchy` to understand how the UI is structured before mapping updates to the mobile app.",
  tools: [listRecentChanges, getDesignTokens, getComponentHierarchy],
});
